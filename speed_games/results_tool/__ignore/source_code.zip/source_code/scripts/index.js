import Infiniship from "@yuigoto/infiniship-js";
import sortBy from 'lodash/fp/sortBy'
import mean from 'lodash/fp/mean'
import JSConfetti from 'js-confetti'


const SETTINGS = {
    duration: 13,
    sprites: {
        h: 48,
        w: 48
    }
}

const URL_TO_NAME = {
    "https://coordinated-bumpy-turner.glitch.me": "MediahuisNoord",
    "https://jealous-hollow-dash.glitch.me": "Jealous Hollow Dash",
    "https://rattle-imported-wishbone.glitch.me": "de kroketjes",
    "https://winter-snapdragon-cosmonaut.glitch.me": "winter-snapdragon-cosmonaut",
    "https://snow-ribbon-nannyberry.glitch.me": "inside-booking",
    "https://clammy-bony-tuesday.glitch.me": "clammy-bony-tuesday",
    "https://second-humble-way.glitch.me": "SecondHumbleWay",
    "https://pollen-zenith-crowley.glitch.me": "The Independent",
    "https://coffee-google-12.glitch.me": "coffee-google-12",
    "https://ludicrous-impartial-enigmosaurus.glitch.me": "Zimmarktplaats",
}

//https://deep-fold.itch.io/space-background-generator
const SCENES = [
    {
        title: "Largest Contentful Paint",
        bg: "bg-red",
        dataKey: "chromeUserTiming.LargestContentfulPaint"
    },
    {
        title: "Time to first Ad request",
        bg: "bg-grey",
        dataKey: "userTime.gpt-ad-request"
    },
    {
        title: "First Contentful Paint",
        bg: "bg-orange",
        dataKey: "chromeUserTiming.firstContentfulPaint"
    },
]


/**
 * 
 * 
 * 
 * CODE
 * 
 * 
 * 
 */

let globalInputData;
let players;
let selectedSceneIndex;
const ShipGenerator = new Infiniship();

const randomMinMax = (min, max) => (Math.random() * (max - min) + min).toFixed(4)
const randomColor = () => `#${Math.floor(Math.random() * 16777215).toString(16)}`;

const displayAndSetPlayers = () => {
    const container = document.querySelector('#player-container')
    const template = document.querySelector('#player-template')

    players = Object.keys(globalInputData).map((url, index) => {
        return {
            url: url,
            name: URL_TO_NAME[url] ?? url,
            index: (index + 1).toString(),
            color: randomColor()
        }
    })

    players.forEach((candidate, index) => {
        const item = template.content.cloneNode(true);
        item.querySelector('.index').textContent = candidate.index
        item.querySelector('.index').style.background = candidate.color
        item.querySelector('.name').textContent = `${candidate.name}`
        item.querySelector('.url').textContent = `${candidate.url}`
        // item.querySelector('.value').textContent = candidate.value.toFixed(2)
        container.appendChild(item);
    });

}

const runScene = (settings, candidates) => {
    const scores = candidates.map(c => c.value)
    const minScore = Math.min(...scores);
    const maxScore = Math.max(...scores);
    const candidateCount = candidates.length
    const duration = SETTINGS.duration

    document.querySelector('#counter-scene').style.display = 'none'
    document.querySelector('#scene').style.display = 'block'
    document.querySelector('.leaderboard').style.display = 'none'
    document.querySelector('#ship-container').innerHTML = ""
    document.querySelector('#leaderboard-container').innerHTML = ""
    document.querySelector('.background-title').innerHTML = settings.title

    setTimeout(() => { onEndRace() }, (duration * 1000) + 500);

    console.log(candidates.length)
    candidates.forEach((candidate, index) => {
        const candidateScore = candidate.value;
        const value = (candidateScore - minScore) / (maxScore - minScore)

        const ship = document.createElement('div');
        const p = document.createElement('p')
        const img = ShipGenerator.generateShipImage();

        ship.style.animationDuration = `${randomMinMax(1, 3)}s`
        ship.style.animationDelay = `${randomMinMax(0, .2)}s`
        ship.classList.add('ship')
        ship.style.background = candidate.color
        img.height = SETTINGS.sprites.h;
        img.width = SETTINGS.sprites.w;
        p.innerHTML = candidate.index.toString()
        ship.append(p)
        ship.append(img)
        document.querySelector('#ship-container').append(ship);

        const POSITION = `${((value) * 30) + 2}vh`

        ship.style.top = `calc(90vh - ${SETTINGS.sprites.h}px)`
        ship.style.left = `${(index * (90 / candidateCount)) + 5}vw`
        const key = `ship-${index}`
        ship.id = key

        setTimeout(() => {
            const r = () => randomMinMax(0.2, 0.99)
            const y = () => randomMinMax(0.2, 0.99)
            console.log(r())
            ship.style.transition = `all ${duration}s cubic-bezier(${r()},${r()},${y()},${y()})`
            // ship.style.transition = `all ${duration}s ease`
            ship.style.top = POSITION;
        }, 200)
    })

    const onEndRace = () => {
        document.querySelector('.leaderboard').style.display = 'block'
        const container = document.querySelector('#leaderboard-container')
        const template = document.querySelector('#leaderboard-template')
        const sorted = sortBy(x => x.value, Object.assign({}, candidates))

        setTimeout(() => {
            Array.from(document.querySelectorAll('.ship')).forEach(element => {
                console.log('element', element)
                element.style.transition = 'none'
                element.style.animation = 'none'
            })
        }, 10);

        shootConfetti();

        sorted.forEach((candidate, index) => {
            console.log('sorted', index)
            const item = template.content.cloneNode(true);
            item.querySelector('.place').textContent = `${index + 1}. `
            item.querySelector('.index').textContent = candidate.index.toString()
            item.querySelector('.index').style.background = candidate.color
            item.querySelector('.name').textContent = `${candidate.name}: `
            item.querySelector('.value').textContent = candidate.value.toFixed(2)
            container.appendChild(item);
        });
        settings.callback?.();
    }

}

document.querySelector("#input").addEventListener("input", (event) => {
    Papa.parse(event.target.files[0], {
        header: true,
        complete: inputCallback
    });
})

const inputCallback = (raw) => {
    const data = raw.data
    const header = data.shift();
    let result = {}
    raw.data.forEach(row => {
        const url = row['URL'];
        Object.keys(row).forEach(key => {
            if (typeof result?.[url] === 'undefined') {
                result[url] = {}
            }
            if (typeof result?.[url]?.[key] === 'undefined') {
                result[url][key] = []
            }
            result[url][key] = [
                ...((result[url] ?? {})[key] ?? []),
                Number(row[key])
            ]
        })
    })
    globalInputData = result;
    document.querySelector('#input-scene').style.display = 'none'
    document.querySelector('#waiting-scene').style.display = 'none'
    document.querySelector('#player-scene').style.display = 'block'

    // document.querySelector('#waiting-scene').querySelector('.press').style.display = 'block'
    displayAndSetPlayers();
}

//https://codepen.io/FlorinPop17/pen/LzYNWa
const runCountdown = (callback) => {
    document.querySelector('#counter-scene').style.display = 'block';
    document.querySelector('#scene').style.display = 'none'
    document.querySelector('#input-scene').style.display = 'none'
    document.querySelector('#waiting-scene').style.display = 'none'

    const nums = document.querySelectorAll('.nums span');
    const counter = document.querySelector('.counter');
    const finalMessage = document.querySelector('.final');

    function resetDOM() {
        counter.classList.remove('hide');
        finalMessage.classList.remove('show');

        nums.forEach(num => {
            num.classList.value = '';
        });
        nums[0].classList.add('in');
    }

    resetDOM();
    runAnimation();

    function runAnimation() {
        nums.forEach((num, idx) => {
            const penultimate = nums.length - 1;
            num.addEventListener('animationend', (e) => {
                if (e.animationName === 'goIn' && idx !== penultimate) {
                    num.classList.remove('in');
                    num.classList.add('out');
                } else if (e.animationName === 'goOut' && num.nextElementSibling) {
                    num.nextElementSibling.classList.add('in');
                } else {
                    counter.classList.add('hide');
                    finalMessage.classList.add('show');
                }
            });
        });
    }
}

const setup = () => {
    document.querySelector('#counter-scene').style.display = 'none'
    document.querySelector('#scene').style.display = 'none'
    document.querySelector('#waiting-scene').style.display = 'block'
    document.querySelector('#player-scene').style.display = 'none'
    // document.querySelector('#waiting-scene').querySelector('.press').style.display = 'none'
}

window.addEventListener('keyup', event => {


    if (event.code !== 'Space' && Number(event.key) <= SCENES.length) {
        selectedSceneIndex = Number(event.key) - 1
        const scene = SCENES[Number(event.key) - 1]

        document.querySelector('#player-scene').style.display = 'none'
        document.querySelector('#counter-scene').style.display = 'none'
        document.querySelector('#scene').style.display = 'none'
        document.querySelector('#waiting-scene').style.display = 'block'
        document.querySelector('#leaderboard-container').innerHTML = ""

        document.querySelector('body').style.backgroundImage = `url(${scene.bg}.png)`;
        document.querySelector('#waiting-scene').querySelector('.title').innerHTML = scene.title
        document.querySelector('#scene').querySelector('.background-title').innerHTML = scene.title

    }

    if (event.key === 'c') {
        shootConfetti()
    }


    if (event.code === 'Space') {
        const scene = SCENES[selectedSceneIndex]
        const candidates = getCandidates();
        console.log(candidates)
        runCountdown();
        setTimeout(() => {
            console.log("Running scene")
            runScene({ title: scene.title, callback: () => { } }, candidates);
        }, 5000);
    }

})

const getCandidates = () => {
    const scene = SCENES[selectedSceneIndex]
    let candidates = {}
    Object.keys(globalInputData).forEach(rowKey => {
        let values = globalInputData[rowKey][scene.dataKey] ?? [];
        values = values.filter(x => !Number.isNaN(x) && Number(x) > 0)
        let medianValue = values.length > 0 ? mean(values) : undefined;
        if (medianValue !== undefined) {
            candidates[rowKey] = medianValue
        } else {
            console.error(rowKey, ' has no median value!')
        }
    })
    let arr = Object.keys(candidates).map((key, index) => {
        const playerObject = players.find(p => p.url === key)

        return {
            index: playerObject.index,
            url: key,
            name: playerObject.name,
            value: candidates[key],
            color: playerObject.color
        }
    })
    arr = sortBy(x => x.index, arr)
    return arr
}


//https://github.com/loonywizard/js-confetti
const shootConfetti = () => {
    const jsConfetti = new JSConfetti()
    jsConfetti.addConfetti({
        emojis: ['🏆', '🥈', '🥉', '🥇'],
    })
}

setup();