1. In a terminal: `npm install`
2. In a terminal: `npm run build`
3. Open index.html (preferably with a live server)
4. Gainz